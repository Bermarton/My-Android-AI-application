package com.novelreader

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONTokener
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val homeUrl = "https://novelfire.com"

    private lateinit var web: WebView
    private lateinit var btnToggle: Button
    private lateinit var status: TextView

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private var awaitingLoad = false
    private val handler = Handler(Looper.getMainLooper())
    private var loadTimeout: Runnable? = null

    // ---- JavaScript injected into the page ----
    private val extractJs = """
        (function(){
          var el = document.querySelector('#content') ||
                   document.querySelector('.chapter-content') ||
                   document.querySelector('#chapter-container') ||
                   document.querySelector('article');
          if(!el) return '';
          var parts = [];
          el.querySelectorAll('p').forEach(function(p){
            var s = (p.innerText||'').trim();
            if(s) parts.push(s);
          });
          var title = (document.querySelector('h1,h2.chapter-title,.chapter-title')||{}).innerText || '';
          var body = parts.length ? parts.join('\n') : (el.innerText||'');
          return (title.trim() ? title.trim() + '.\n' : '') + body;
        })();
    """.trimIndent()

    private val clickNextJs = """
        (function(){
          var a = document.querySelector('a.nextchap, a[rel="next"], #next, a.next, .nextchap');
          if(!a){
            var all = document.querySelectorAll('a,button');
            for(var i=0;i<all.length;i++){
              if(/^\s*next/i.test(all[i].innerText||'')){ a = all[i]; break; }
            }
          }
          if(a && !a.classList.contains('isDisabled') && !a.hasAttribute('disabled')){
            a.click();
            return 'ok';
          }
          return 'none';
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        btnToggle = findViewById(R.id.btnToggle)
        status = findViewById(R.id.status)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (running && awaitingLoad) {
                    awaitingLoad = false
                    loadTimeout?.let { handler.removeCallbacks(it) }
                    // small delay so the chapter text is fully rendered
                    handler.postDelayed({ if (running) readCurrentChapter() }, 1500)
                }
            }
        }
        web.loadUrl(homeUrl)

        tts = TextToSpeech(this) { code ->
            if (code == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { if (running) stopReading("Speech error — stopped.") }
                    }
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == "last") runOnUiThread { if (running) goToNextChapter() }
                    }
                })
            } else {
                setStatus("Text-to-speech is not available on this phone.")
            }
        }

        btnToggle.setOnClickListener { if (running) stopReading("Stopped.") else startReading() }
        findViewById<Button>(R.id.btnHome).setOnClickListener { web.loadUrl(homeUrl) }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startReading() {
        if (!ttsReady) { setStatus("Speech engine still starting, try again."); return }
        running = true
        btnToggle.text = "Stop"
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        readCurrentChapter()
    }

    private fun stopReading(message: String) {
        running = false
        awaitingLoad = false
        loadTimeout?.let { handler.removeCallbacks(it) }
        handler.removeCallbacksAndMessages(null)
        tts?.stop()
        stopService(Intent(this, KeepAliveService::class.java))
        btnToggle.text = "Start reading"
        setStatus(message)
    }

    private fun readCurrentChapter() {
        setStatus("Reading chapter…")
        web.evaluateJavascript(extractJs) { raw ->
            val text = decodeJs(raw)
            if (text.isBlank()) {
                stopReading("Couldn't find chapter text on this page. Open a chapter first.")
                return@evaluateJavascript
            }
            val chunks = splitText(text)
            tts?.stop()
            chunks.forEachIndexed { i, chunk ->
                val id = if (i == chunks.lastIndex) "last" else "c$i"
                tts?.speak(chunk, TextToSpeech.QUEUE_ADD, null, id)
            }
        }
    }

    private fun goToNextChapter() {
        setStatus("Opening next chapter…")
        web.evaluateJavascript(clickNextJs) { raw ->
            if (decodeJs(raw) == "ok") {
                awaitingLoad = true
                // fallback in case the site loads the next chapter without a full page load
                loadTimeout = Runnable {
                    if (running && awaitingLoad) {
                        awaitingLoad = false
                        readCurrentChapter()
                    }
                }.also { handler.postDelayed(it, 10000) }
            } else {
                stopReading("No 'Next' button found — probably the last chapter.")
            }
        }
    }

    private fun decodeJs(raw: String?): String {
        if (raw == null || raw == "null") return ""
        return try { JSONTokener(raw).nextValue() as? String ?: "" } catch (e: Exception) { "" }
    }

    /** TTS engines limit input length, so split into sentence-sized chunks. */
    private fun splitText(text: String): List<String> {
        val max = minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 3500)
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for (piece in text.split(Regex("(?<=[.!?\\n])\\s+"))) {
            if (sb.length + piece.length + 1 > max && sb.isNotEmpty()) {
                out.add(sb.toString()); sb.clear()
            }
            if (piece.length > max) {
                piece.chunked(max).forEach { out.add(it) }
            } else {
                sb.append(piece).append(' ')
            }
        }
        if (sb.isNotBlank()) out.add(sb.toString())
        return out
    }

    private fun setStatus(s: String) { status.text = s }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        stopService(Intent(this, KeepAliveService::class.java))
        super.onDestroy()
    }
}
